const addNew = document.getElementById("add-new");
const container = document.getElementById("container");

function saveCardsToLocalStorage() {
    const cards = [];
    document.querySelectorAll(".card").forEach((card) => {
        const title = card.querySelector(".title").innerText;
        const content = card.querySelector(".content").innerText;
        cards.push({ title, content });
    });
    localStorage.setItem("cards", JSON.stringify(cards));
}

// Function to load cards from localStorage
function loadCardsFromLocalStorage() {
    const savedCards = JSON.parse(localStorage.getItem("cards") || "[]");
    savedCards.forEach(({ title, content }) => {
        createCard(title, content);
    });
}

function createCard(titleText = "Title", contentText = "Content") {
    let card = document.createElement("div");
    card.classList.add("card");

    // Header
    let title = document.createElement("h1");
    title.innerText = titleText;
    title.className = "title";
    card.appendChild(title);

    // Content
    let content = document.createElement("p");
    content.innerText = contentText;
    content.className = "content";
    card.appendChild(content);

    // Edit button
    let edit = document.createElement("button");
    edit.innerText = "Edit";
    edit.classList.add("edit");
    card.appendChild(edit);

    // Save button
    let save = document.createElement("button");
    save.innerText = "Save";
    save.classList.add("save");
    card.appendChild(save);

    // Delete button
    let remove = document.createElement("button");
    remove.innerText = "Remove";
    remove.classList.add("remove");
    card.appendChild(remove);

    container.appendChild(card);
}

container.addEventListener("click", function (e) {
    if (e.target.classList.contains("edit")) {
        const card = e.target.parentElement;
        const title = card.querySelector(".title");
        const content = card.querySelector(".content");
        title.contentEditable = true;
        content.contentEditable = true;
        title.focus();
    } else if (e.target.classList.contains("save")) {
        saveCardsToLocalStorage();
        const card = e.target.parentElement;
        const title = card.querySelector(".title");
        const content = card.querySelector(".content");
        title.contentEditable = false;
        content.contentEditable = false;
    } else if (e.target.classList.contains("remove")) {
        e.target.parentElement.remove();
        saveCardsToLocalStorage();
    }
}, false);

// Add new task button logic
addNew.addEventListener("click", () => {
    createCard();
    saveCardsToLocalStorage();
});

// Load cards on page load
loadCardsFromLocalStorage();